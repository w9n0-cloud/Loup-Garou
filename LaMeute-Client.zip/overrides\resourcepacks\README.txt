🐺 RESOURCE PACKS RECOMMANDÉS POUR LA MEUTE 🌕
==============================================

Pour une immersion maximale dans l'univers Loup-Garou :

1. MEDIEVAL TEXTURES (Recommandé)
   - Stay True : https://modrinth.com/resourcepack/stay-true
   - Fait ressortir le style médiéval tout en gardant le vanilla

2. FAITHFUL 32X
   - https://faithfulpack.net
   - Textures vanilla améliorées en 32x32
   - Compatible avec tous les mods

3. MIZUNO'S 16 CRAFT
   - https://mizunomcmemo.blogspot.com
   - Style RPG médiéval japonais
   - Très atmosphérique

4. DARK MEDIEVAL
   - Cherchez sur CurseForge/Modrinth
   - Ambiance sombre parfaite pour les nuits

📁 INSTALLATION :
1. Téléchargez le resource pack
2. Placez le .zip dans ce dossier
3. Options > Resource Packs
4. Activez le pack

🎵 MUSIQUE RECOMMANDÉE :
- Installez le mod "Music Maker Mod" pour de la musique d'ambiance
- Ou utilisez un lecteur externe avec :
  * OST de The Witcher
  * Musique médiévale
  * Ambiance forêt nocturne

🌙 Bonne chasse !
