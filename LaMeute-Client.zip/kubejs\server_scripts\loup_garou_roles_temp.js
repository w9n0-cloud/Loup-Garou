


// ============================================

// ============================================

let playerTitles = {};

const titleColors = {
    'dev': '§b§l[DEV] ',
    'maitre du jeu': '§6§l[MJ] ',
    'mj': '§6§l[MJ] ',
    'owner': '§4§l[OWNER] ',
    'admin': '§c§l[ADMIN] ',
    'modo': '§e§l[MODO] ',
    'vip': '§a§l[VIP] ',
    'tasty crousty': '§d§l[Tasty Crousty] ',
    'chicken street': '§6§l[Chicken Street] ',
    'joueur': '§7[Joueur] '
};


function getFormattedTitle(title) {
    const lowerTitle = title.toLowerCase();
    if (titleColors[lowerTitle]) {
        return titleColors[lowerTitle];
    }
    return '§e§l[' + title + '] ';
}

function updatePlayerDisplayName(player) {
    const playerName = player.name.string;
    const title = playerTitles[playerName] || 'Joueur';
    const formattedTitle = getFormattedTitle(title);
    const displayName = formattedTitle + '§f' + playerName;
    player.displayName = displayName;
    player.server.runCommandSilent('team add title_' + playerName.replace(/[^a-zA-Z0-9]/g, '') + ' ""');
    player.server.runCommandSilent('team join title_' + playerName.replace(/[^a-zA-Z0-9]/g, '') + ' ' + playerName);
    player.server.runCommandSilent('team modify title_' + playerName.replace(/[^a-zA-Z0-9]/g, '') + ' prefix ' + JSON.stringify({"text":formattedTitle.replace(/§/g, '\u00A7')}));
}

// ============================================

// ============================================

let arenaCenter = {
    x: 0,
    y: 100,
    z: 0,
    set: false,
    radius: 5
};

function teleportPlayersInCircle(server) {
    let players = [];
    server.players.forEach(p => {
        if (p.hasTag('loupgarou_playing')) {
            players.push(p);
        }
    });
    
    if (players.length === 0) {
        server.players.forEach(p => players.push(p));
    }
    
    const count = players.length;
    const angleStep = (2 * Math.PI) / count;
    
    players.forEach((player, index) => {
        const angle = angleStep * index;
        const x = arenaCenter.x + Math.cos(angle) * arenaCenter.radius;
        const z = arenaCenter.z + Math.sin(angle) * arenaCenter.radius;
        const y = arenaCenter.y;
        
        player.server.runCommandSilent('tp ' + player.name.string + ' ' + x.toFixed(1) + ' ' + y + ' ' + z.toFixed(1));
        player.server.runCommandSilent('tp ' + player.name.string + ' ' + x.toFixed(1) + ' ' + y + ' ' + z.toFixed(1) + ' facing ' + arenaCenter.x + ' ' + y + ' ' + arenaCenter.z);
    });
    
    return count;
}

// ============================================

// ============================================

let timerConfig = {
    dayDuration: 5,
    nightDuration: 6,
    currentPhase: 'none',
    timerStartTime: 0,
    timerRunning: false,
    autoMode: false
};

let nightActionsCompleted = {
    loups: false,
    voyante: false,
    sorciere_checked: false,
    salvateur: false
};

function resetNightActions() {
    nightActionsCompleted = {
        loups: false,
        voyante: false,
        sorciere_checked: false,
        salvateur: false
    };
}


function allNightActionsComplete(level) {
    let hasVoyante = false;
    let hasSorciere = false;
    let hasSalvateur = false;
    let hasLoups = false;
    
    level.players.forEach(p => {
        if (p.hasTag('voyante')) hasVoyante = true;
        if (p.hasTag('sorciere')) hasSorciere = true;
        if (p.hasTag('salvateur')) hasSalvateur = true;
        if (p.hasTag('loup_garou')) hasLoups = true;
    });
    

    if (hasLoups && !nightActionsCompleted.loups) return false;
    if (hasVoyante && !nightActionsCompleted.voyante) return false;
    if (hasSalvateur && !nightActionsCompleted.salvateur) return false;

    
    return true;
}


function transitionToDay(server) {
    timerConfig.currentPhase = 'day';
    timerConfig.timerStartTime = Date.now();
    votePhaseActive = true;
    nightPhaseActive = false;
    votes = {};
    

    let loupTarget = null;
    let loupVoteCount = {};
    
    for (let loup in loupVotes) {
        let target = loupVotes[loup];
        loupVoteCount[target] = (loupVoteCount[target] || 0) + 1;
    }
    
    let maxLoupVotes = 0;
    for (let target in loupVoteCount) {
        if (loupVoteCount[target] > maxLoupVotes) {
            maxLoupVotes = loupVoteCount[target];
            loupTarget = target;
        }
    }
    

    let victimProtected = false;
    let victimPlayer = null;
    
    server.getPlayers().forEach(p => {
        if (loupTarget && p.name.string === loupTarget) {
            victimPlayer = p;
            if (p.hasTag('protected_tonight')) {
                victimProtected = true;
            }
        }
    });
    
    server.getPlayers().forEach(p => {
        p.tell('');
        p.tell('§6§l═══════════════════════════════════════════════════');
        p.tell('§e§l              ☀️ LE JOUR SE LÈVE ☀️');
        p.tell('');
        
        if (loupTarget && !victimProtected) {
            p.tell('§c§l   ☠ ' + loupTarget + ' a été dévoré cette nuit... ☠');
        } else if (loupTarget && victimProtected) {
            p.tell('§a   ✨ Le Salvateur a protégé quelqu\'un cette nuit !');
            p.tell('§7   Personne n\'est mort.');
        } else {
            p.tell('§7   Personne n\'est mort cette nuit.');
        }
        
        p.tell('');
        p.tell('§a   📊 La barre d\'XP = temps restant pour voter');
        p.tell('§a   👆 CLIC DROIT sur un joueur pour VOTER !');
        p.tell('§7      Clic gauche pour retirer votre vote.');
        p.tell('§6§l═══════════════════════════════════════════════════');
        p.tell('');
        

        p.level.setDayTime(1000);
        

        p.level.playSound(null, p.blockPosition(),
            'minecraft:entity.chicken.ambient', 'ambient', 2.0, 0.8);
    });
    

    if (victimPlayer && !victimProtected) {
        victimPlayer.kill();
    }
}


function transitionToNight(server) {
    timerConfig.currentPhase = 'night';
    timerConfig.timerStartTime = Date.now();
    votePhaseActive = false;
    nightPhaseActive = true;
    

    resetNightActions();
    voyantePowerUsed = {};
    loupVotes = {};
    

    server.getPlayers().forEach(p => {
        p.removeTag('protected_tonight');
    });
    
    server.getPlayers().forEach(p => {
        p.tell('');
        p.tell('§8§l═══════════════════════════════════════════════════');
        p.tell('§c§l              🌙 LA NUIT TOMBE 🌙');
        p.tell('§7     Le village s\'endort... Les loups se réveillent.');
        p.tell('');
        p.tell('§7   📊 La barre d\'XP = temps restant');
        p.tell('§7   ⚡ Si tout le monde joue vite, la nuit passe plus vite !');
        p.tell('');
        
        if (p.hasTag('loup_garou')) {
            p.tell('§c     🐺 Utilisez un OS sur un joueur pour le dévorer');
        }
        if (p.hasTag('voyante')) {
            p.tell('§b     👁 Utilisez un ŒIL D\'ARAIGNÉE pour voir un rôle');
        }
        if (p.hasTag('sorciere')) {
            p.tell('§d     ⚗ POMME DORÉE = vie | ROSE DES TÉNÈBRES = mort');
        }
        if (p.hasTag('salvateur')) {
            p.tell('§f     🛡 Utilisez un BOUCLIER pour protéger quelqu\'un');
        }
        
        p.tell('§8§l═══════════════════════════════════════════════════');
        p.tell('');
        

        p.level.setDayTime(13000);
        

        p.level.playSound(null, p.blockPosition(),
            'minecraft:entity.wolf.howl', 'ambient', 1.0, 0.6);
    });
}


function executeVoteResult(server) {

    let voteCount = {};
    for (let voter in votes) {
        let target = votes[voter];
        voteCount[target] = (voteCount[target] || 0) + 1;
    }
    

    let maxVotes = 0;
    let eliminated = null;
    for (let player in voteCount) {
        if (voteCount[player] > maxVotes) {
            maxVotes = voteCount[player];
            eliminated = player;
        }
    }
    
    server.getPlayers().forEach(p => {
        p.tell('');
        p.tell('§6§l═══════════════════════════════════════════════════');
        p.tell('§c§l              ⚖️ RÉSULTAT DU VOTE ⚖️');
        p.tell('');
        

        for (let voter in votes) {
            p.tell('§7  ' + voter + ' → §c' + votes[voter]);
        }
        
        p.tell('');
        if (eliminated) {
            p.tell('§4§l  ☠ ' + eliminated + ' est éliminé avec ' + maxVotes + ' vote(s) !');
            

            server.getPlayers().forEach(target => {
                if (target.name.string === eliminated) {
                    let role = 'Villageois';
                    if (target.hasTag('loup_garou')) role = '§cLOUP-GAROU 🐺';
                    else if (target.hasTag('voyante')) role = '§bVoyante';
                    else if (target.hasTag('sorciere')) role = '§dSorcière';
                    else if (target.hasTag('chasseur')) role = '§6Chasseur';
                    else if (target.hasTag('cupidon')) role = '§eCupidon';
                    else if (target.hasTag('salvateur')) role = '§fSalvateur';
                    else if (target.hasTag('petite_fille')) role = '§ePetite Fille';
                    else role = '§aVillageois';
                    
                    p.tell('§7  Son rôle était : ' + role);
                    target.kill();
                }
            });
        } else {
            p.tell('§7  Aucun vote enregistré. Personne n\'est éliminé.');
        }
        p.tell('§6§l═══════════════════════════════════════════════════');
        p.tell('');
        

        p.level.playSound(null, p.blockPosition(),
            'minecraft:entity.lightning_bolt.thunder', 'players', 0.5, 0.8);
    });
    
    votes = {};
}


ServerEvents.tick(event => {
    if (!timerConfig.autoMode || !timerConfig.timerRunning) return;
    
    const server = event.server;
    const now = Date.now();
    let phaseDuration;
    
    if (timerConfig.currentPhase === 'day') {
        phaseDuration = timerConfig.dayDuration * 60 * 1000; // en ms
    } else if (timerConfig.currentPhase === 'night') {
        phaseDuration = timerConfig.nightDuration * 60 * 1000; // en ms
        

        let allComplete = true;
        server.getPlayers().forEach(p => {
            if (!allNightActionsComplete(p.level)) {
                allComplete = false;
            }
        });
        
        if (allComplete && (now - timerConfig.timerStartTime) > 10000) {

            server.getPlayers().forEach(p => {
                p.tell('§a§l⚡ Tous les rôles ont joué ! Passage au jour dans 5 secondes...');
            });
            
            server.scheduleInTicks(100, () => {
                if (timerConfig.currentPhase === 'night') {
                    executeVoteResult(server); // Pas de vote la nuit, mais on skip
                    transitionToDay(server);
                }
            });
            return;
        }
    } else {
        return;
    }
    
    const elapsed = now - timerConfig.timerStartTime;
    const remaining = Math.max(0, phaseDuration - elapsed);
    const progress = remaining / phaseDuration;
    


    server.getPlayers().forEach(p => {

        const minutesLeft = Math.ceil(remaining / 60000);
        p.setExperienceLevel(minutesLeft);
        

        p.setExperienceProgress(progress);
        

        if (remaining <= 30000 && remaining > 29000) {
            p.tell('§c§l⚠ 30 SECONDES RESTANTES !');
            p.level.playSound(null, p.blockPosition(),
                'minecraft:block.note_block.pling', 'players', 1.0, 0.5);
        }
        if (remaining <= 10000 && remaining > 9000) {
            p.tell('§4§l⚠ 10 SECONDES !');
            p.level.playSound(null, p.blockPosition(),
                'minecraft:block.note_block.pling', 'players', 1.0, 1.0);
        }
    });
    

    if (remaining <= 0) {
        if (timerConfig.currentPhase === 'day') {
            executeVoteResult(server);
            transitionToNight(server);
        } else if (timerConfig.currentPhase === 'night') {
            transitionToDay(server);
        }
    }
});


let pendingCardReveal = {}; // {joueur: role} en attente de clic
let gameStarted = false;

// ============================================

// ============================================


function shuffleArray(array) {
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]];
    }
    return array;
}


function revealRoleToPlayer(player, role) {
    let roleName = '';
    let roleColor = '';
    let roleEmoji = '';
    let roleDescription = '';
    let roleItem = '';
    
    switch(role) {
        case 'loup_garou':
            roleName = 'LOUP-GAROU';
            roleColor = '§c';
            roleEmoji = '🐺';
            roleDescription = 'Dévorez les villageois chaque nuit !';
            roleItem = 'OS pour désigner votre victime';
            break;
        case 'voyante':
            roleName = 'VOYANTE';
            roleColor = '§b';
            roleEmoji = '👁';
            roleDescription = 'Découvrez le rôle d\'un joueur chaque nuit.';
            roleItem = 'ŒIL D\'ARAIGNÉE pour sonder';
            break;
        case 'sorciere':
            roleName = 'SORCIÈRE';
            roleColor = '§d';
            roleEmoji = '⚗';
            roleDescription = 'Vous avez une potion de vie et une de mort.';
            roleItem = 'POMME DORÉE (vie) | ROSE (mort)';
            break;
        case 'chasseur':
            roleName = 'CHASSEUR';
            roleColor = '§6';
            roleEmoji = '🏹';
            roleDescription = 'Si vous mourrez, vous emportez quelqu\'un !';
            roleItem = 'ARC pour tirer votre dernière flèche';
            break;
        case 'cupidon':
            roleName = 'CUPIDON';
            roleColor = '§e';
            roleEmoji = '💕';
            roleDescription = 'Liez deux joueurs par l\'amour éternel.';
            roleItem = 'COQUELICOT pour lier les amoureux';
            break;
        case 'salvateur':
            roleName = 'SALVATEUR';
            roleColor = '§f';
            roleEmoji = '🛡';
            roleDescription = 'Protégez un joueur chaque nuit.';
            roleItem = 'BOUCLIER pour protéger';
            break;
        case 'petite_fille':
            roleName = 'PETITE FILLE';
            roleColor = '§e';
            roleEmoji = '👀';
            roleDescription = 'Espionnez les loups... sans vous faire voir !';
            roleItem = 'Restez cachée et observez';
            break;
        default:
            roleName = 'VILLAGEOIS';
            roleColor = '§a';
            roleEmoji = '🏠';
            roleDescription = 'Trouvez et éliminez les loups-garous !';
            roleItem = 'Votre voix et votre intuition';
    }
    

    player.server.runCommandSilent('title ' + player.name.string + ' times 20 100 20');
    player.server.runCommandSilent('title ' + player.name.string + ' subtitle {"text":"' + roleDescription + '","color":"gray","italic":true}');
    player.server.runCommandSilent('title ' + player.name.string + ' title {"text":"' + roleEmoji + ' ' + roleName + ' ' + roleEmoji + '","color":"' + roleColor.replace('§', '') + '","bold":true}');
    

    player.tell('');
    player.tell(roleColor + '§l╔══════════════════════════════════════════╗');
    player.tell(roleColor + '§l║                                          ║');
    player.tell(roleColor + '§l║     ' + roleEmoji + ' VOTRE CARTE : ' + roleName + ' ' + roleEmoji + '     ');
    player.tell(roleColor + '§l║                                          ║');
    player.tell(roleColor + '§l╠══════════════════════════════════════════╣');
    player.tell('§7  ' + roleDescription);
    player.tell('');
    player.tell('§7  §lItem : §r§e' + roleItem);
    player.tell('');
    player.tell('§8  Shift + Regarder en l\'air = Revoir votre rôle');
    player.tell(roleColor + '§l╚══════════════════════════════════════════╝');
    player.tell('');
    

    player.level.playSound(null, player.blockPosition(), 
        'minecraft:ui.toast.challenge_complete', 'players', 1.0, 1.0);
    

    const allRoles = ['loup_garou', 'villageois', 'voyante', 'sorciere', 
                     'chasseur', 'cupidon', 'salvateur', 'petite_fille'];
    allRoles.forEach(r => player.removeTag(r));
    player.addTag(role);
    

    switch(role) {
        case 'loup_garou':
            player.give('minecraft:bone');
            break;
        case 'voyante':
            player.give('minecraft:spider_eye');
            break;
        case 'sorciere':
            player.give('minecraft:golden_apple');
            player.give('minecraft:wither_rose');
            break;
        case 'chasseur':
            player.give('minecraft:bow');
            player.give('minecraft:arrow');
            break;
        case 'cupidon':
            player.give('minecraft:poppy');
            break;
        case 'salvateur':
            player.give('minecraft:shield');
            break;
    }
}


PlayerEvents.rightClickedBlock(event => {
    const player = event.player;
    const playerName = player.name.string;
    

    if (pendingCardReveal[playerName]) {
        const role = pendingCardReveal[playerName];
        delete pendingCardReveal[playerName];
        
        revealRoleToPlayer(player, role);
        event.cancel();
    }
});


PlayerEvents.rightClickedEmpty(event => {
    const player = event.player;
    const playerName = player.name.string;
    

    if (pendingCardReveal[playerName]) {
        const role = pendingCardReveal[playerName];
        delete pendingCardReveal[playerName];
        
        revealRoleToPlayer(player, role);
    }
});


let votes = {};
let votePhaseActive = false;


let voyantePowerUsed = {};      // {joueur: true} si déjà utilisé cette nuit
let sorcierePotionVie = {};     // {joueur: true} si potion encore dispo
let sorcierePotionMort = {};    // {joueur: true} si potion encore dispo
let salvateurProtection = {};   // {joueur: "cible"} dernière protection
let cupidonLinks = {};          // {joueur1: joueur2, joueur2: joueur1}
let chasseurCanShoot = {};      // {joueur: true} si peut encore tirer
let loupVotes = {};             // {loup: "cible"} vote des loups
let nightPhaseActive = false;

// ============================================

// ============================================
ItemEvents.rightClicked('minecraft:spider_eye', event => {
    const player = event.player;
    
    if (!nightPhaseActive) {
        player.tell('§c[Voyante] §7Vous ne pouvez utiliser ce pouvoir que la nuit.');
        return;
    }
    
    if (!player.hasTag('voyante')) {
        return; // Pas voyante, ne rien faire
    }
    
    if (voyantePowerUsed[player.name.string]) {
        player.tell('§b[Voyante] §7Vous avez déjà utilisé votre pouvoir cette nuit.');
        return;
    }
    

    const lookingAt = player.rayTrace(5, true);
    if (lookingAt && lookingAt.entity && lookingAt.entity.type === 'minecraft:player') {
        const target = lookingAt.entity;
        const targetName = target.name.string;
        

        let role = '§aVillageois';
        if (target.hasTag('loup_garou')) role = '§c§lLOUP-GAROU 🐺';
        else if (target.hasTag('voyante')) role = '§bVoyante';
        else if (target.hasTag('sorciere')) role = '§dSorcière';
        else if (target.hasTag('chasseur')) role = '§6Chasseur';
        else if (target.hasTag('cupidon')) role = '§eCupidon';
        else if (target.hasTag('salvateur')) role = '§fSalvateur';
        else if (target.hasTag('petite_fille')) role = '§ePetite Fille';
        
        player.tell('§b§l══════════════════════════════');
        player.tell('§b      👁 VISION DE LA VOYANTE 👁');
        player.tell('');
        player.tell('§7      ' + targetName + ' est : ' + role);
        player.tell('§b§l══════════════════════════════');
        
        voyantePowerUsed[player.name.string] = true;
        nightActionsCompleted.voyante = true; // Marquer l'action comme complétée
        

        player.level.playSound(null, player.blockPosition(), 
            'minecraft:block.enchantment_table.use', 'players', 1.0, 1.2);
    } else {
        player.tell('§b[Voyante] §7Regardez un joueur et faites clic droit avec l\'œil.');
    }
});

// ============================================

// ============================================
ItemEvents.rightClicked('minecraft:golden_apple', event => {
    const player = event.player;
    
    if (!player.hasTag('sorciere')) return;
    
    if (!nightPhaseActive) {
        player.tell('§d[Sorcière] §7Vous ne pouvez utiliser ce pouvoir que la nuit.');
        return;
    }
    
    if (sorcierePotionVie[player.name.string] === false) {
        player.tell('§d[Sorcière] §7Vous avez déjà utilisé votre potion de vie.');
        return;
    }
    
    const lookingAt = player.rayTrace(5, true);
    if (lookingAt && lookingAt.entity && lookingAt.entity.type === 'minecraft:player') {
        const target = lookingAt.entity;
        
        target.heal(20);
        target.tell('§a§l✨ La Sorcière vous a sauvé avec sa potion de vie ! ✨');
        player.tell('§d[Sorcière] §aVous avez utilisé la potion de vie sur §e' + target.name.string);
        
        sorcierePotionVie[player.name.string] = false;
        

        event.item.count--;
        
        player.level.playSound(null, target.blockPosition(), 
            'minecraft:item.totem.use', 'players', 0.5, 1.2);
    } else {
        player.tell('§d[Sorcière] §7Regardez un joueur pour utiliser la potion de vie.');
    }
});

// ============================================

// ============================================
ItemEvents.rightClicked('minecraft:wither_rose', event => {
    const player = event.player;
    
    if (!player.hasTag('sorciere')) return;
    
    if (!nightPhaseActive) {
        player.tell('§d[Sorcière] §7Vous ne pouvez utiliser ce pouvoir que la nuit.');
        return;
    }
    
    if (sorcierePotionMort[player.name.string] === false) {
        player.tell('§d[Sorcière] §7Vous avez déjà utilisé votre potion de mort.');
        return;
    }
    
    const lookingAt = player.rayTrace(5, true);
    if (lookingAt && lookingAt.entity && lookingAt.entity.type === 'minecraft:player') {
        const target = lookingAt.entity;
        
        target.kill();
        player.tell('§d[Sorcière] §cVous avez empoisonné §e' + target.name.string);
        target.tell('§4§l☠ La Sorcière vous a empoisonné... Vous êtes mort. ☠');
        
        sorcierePotionMort[player.name.string] = false;
        

        event.item.count--;
        
        player.level.playSound(null, target.blockPosition(), 
            'minecraft:entity.wither.spawn', 'players', 0.3, 1.5);
    } else {
        player.tell('§d[Sorcière] §7Regardez un joueur pour utiliser la potion de mort.');
    }
});

// ============================================

// ============================================
ItemEvents.rightClicked('minecraft:shield', event => {
    const player = event.player;
    
    if (!player.hasTag('salvateur')) return;
    
    if (!nightPhaseActive) {
        player.tell('§f[Salvateur] §7Vous ne pouvez protéger que la nuit.');
        return;
    }
    
    const lookingAt = player.rayTrace(5, true);
    if (lookingAt && lookingAt.entity && lookingAt.entity.type === 'minecraft:player') {
        const target = lookingAt.entity;
        const targetName = target.name.string;
        

        if (salvateurProtection[player.name.string] === targetName) {
            player.tell('§f[Salvateur] §cVous ne pouvez pas protéger la même personne deux nuits de suite !');
            return;
        }
        
        salvateurProtection[player.name.string] = targetName;
        target.addTag('protected_tonight');
        nightActionsCompleted.salvateur = true; // Marquer l'action comme complétée
        
        player.tell('§f[Salvateur] §aVous protégez §e' + targetName + ' §acette nuit.');
        
        player.level.playSound(null, target.blockPosition(), 
            'minecraft:item.shield.block', 'players', 1.0, 1.0);
    } else {
        player.tell('§f[Salvateur] §7Regardez un joueur pour le protéger.');
    }
});

// ============================================

// ============================================
let cupidonFirstChoice = {};

ItemEvents.rightClicked('minecraft:poppy', event => {
    const player = event.player;
    
    if (!player.hasTag('cupidon')) return;
    

    if (Object.keys(cupidonLinks).length > 0) {
        player.tell('§e[Cupidon] §7Vous avez déjà lié un couple.');
        return;
    }
    
    const lookingAt = player.rayTrace(5, true);
    if (lookingAt && lookingAt.entity && lookingAt.entity.type === 'minecraft:player') {
        const target = lookingAt.entity;
        const targetName = target.name.string;
        
        if (!cupidonFirstChoice[player.name.string]) {

            cupidonFirstChoice[player.name.string] = targetName;
            player.tell('§e[Cupidon] §7Premier amoureux : §d' + targetName);
            player.tell('§e[Cupidon] §7Maintenant, cliquez sur le deuxième amoureux.');
            
            player.level.playSound(null, player.blockPosition(), 
                'minecraft:entity.experience_orb.pickup', 'players', 1.0, 1.5);
        } else {

            const firstLover = cupidonFirstChoice[player.name.string];
            
            if (firstLover === targetName) {
                player.tell('§e[Cupidon] §cVous ne pouvez pas lier quelqu\'un avec lui-même !');
                return;
            }
            

            cupidonLinks[firstLover] = targetName;
            cupidonLinks[targetName] = firstLover;
            
            player.tell('§e§l═══════════════════════════════════');
            player.tell('§d§l       💕 COUPLE FORMÉ ! 💕');
            player.tell('§e  ' + firstLover + ' §d❤ §e' + targetName);
            player.tell('§e§l═══════════════════════════════════');
            

            player.level.players.forEach(p => {
                if (p.name.string === firstLover || p.name.string === targetName) {
                    p.tell('§d§l═══════════════════════════════════');
                    p.tell('§d§l       💕 VOUS ÊTES AMOUREUX ! 💕');
                    p.tell('§7 Si l\'un de vous meurt, l\'autre aussi...');
                    p.tell('§d§l═══════════════════════════════════');
                    p.addTag('amoureux');
                }
            });
            

            event.item.count--;
            
            player.level.playSound(null, player.blockPosition(), 
                'minecraft:entity.player.levelup', 'players', 1.0, 1.2);
            
            delete cupidonFirstChoice[player.name.string];
        }
    } else {
        player.tell('§e[Cupidon] §7Regardez un joueur pour le lier par l\'amour.');
    }
});

// ============================================

// ============================================
ItemEvents.rightClicked('minecraft:bone', event => {
    const player = event.player;
    
    if (!player.hasTag('loup_garou')) return;
    
    if (!nightPhaseActive) {
        player.tell('§c[Loup-Garou] §7Les loups ne chassent que la nuit...');
        return;
    }
    
    const lookingAt = player.rayTrace(5, true);
    if (lookingAt && lookingAt.entity && lookingAt.entity.type === 'minecraft:player') {
        const target = lookingAt.entity;
        const targetName = target.name.string;
        

        if (target.hasTag('loup_garou')) {
            player.tell('§c[Loup-Garou] §7Vous ne pouvez pas dévorer un membre de la meute !');
            return;
        }
        
        loupVotes[player.name.string] = targetName;
        

        let allLoupsVoted = true;
        let nbLoups = 0;
        let nbLoupsVoted = Object.keys(loupVotes).length;
        
        player.level.players.forEach(p => {
            if (p.hasTag('loup_garou')) nbLoups++;
        });
        
        if (nbLoupsVoted >= nbLoups) {
            nightActionsCompleted.loups = true; // Tous les loups ont voté
        }
        

        player.level.players.forEach(p => {
            if (p.hasTag('loup_garou')) {
                p.tell('§c[Meute] §e' + player.name.string + ' §7veut dévorer §c' + targetName);
            }
        });
        
        player.level.playSound(null, player.blockPosition(), 
            'minecraft:entity.wolf.growl', 'players', 1.0, 0.8);
    } else {
        player.tell('§c[Loup-Garou] §7Regardez un joueur et cliquez avec l\'os pour le désigner.');
    }
});

// ============================================

// ============================================
ItemEvents.rightClicked('minecraft:bow', event => {
    const player = event.player;
    
    if (!player.hasTag('chasseur')) return;
    

    if (!player.hasTag('chasseur_mort')) {
        player.tell('§6[Chasseur] §7Votre arc ne servira que lors de votre dernier souffle...');
        return;
    }
    
    if (chasseurCanShoot[player.name.string] === false) {
        player.tell('§6[Chasseur] §7Vous avez déjà tiré votre dernière flèche.');
        return;
    }
    
    const lookingAt = player.rayTrace(50, true);
    if (lookingAt && lookingAt.entity && lookingAt.entity.type === 'minecraft:player') {
        const target = lookingAt.entity;
        
        target.kill();
        chasseurCanShoot[player.name.string] = false;
        
        player.level.players.forEach(p => {
            p.tell('§6§l═══════════════════════════════════════════');
            p.tell('§6§l       🏹 LE CHASSEUR A TIRÉ ! 🏹');
            p.tell('§7   ' + target.name.string + ' §7a été emporté dans la tombe.');
            p.tell('§6§l═══════════════════════════════════════════');
        });
        
        player.level.playSound(null, target.blockPosition(), 
            'minecraft:entity.arrow.hit_player', 'players', 1.0, 0.8);
    } else {
        player.tell('§6[Chasseur] §7Regardez un joueur pour tirer votre dernière flèche !');
    }
});

// ============================================

// ============================================


let lastScoreboardUpdate = {};

PlayerEvents.tick(event => {
    const player = event.player;
    const playerName = player.name.string;
    

    const now = Date.now();
    if (!lastScoreboardUpdate[playerName] || now - lastScoreboardUpdate[playerName] > 2000) {
        lastScoreboardUpdate[playerName] = now;
        

        let role = '§7???';
        let roleEmoji = '❓';
        
        if (player.hasTag('loup_garou')) { role = '§c§lLOUP-GAROU'; roleEmoji = '🐺'; }
        else if (player.hasTag('voyante')) { role = '§bVoyante'; roleEmoji = '👁'; }
        else if (player.hasTag('sorciere')) { role = '§dSorcière'; roleEmoji = '⚗'; }
        else if (player.hasTag('chasseur')) { role = '§6Chasseur'; roleEmoji = '🏹'; }
        else if (player.hasTag('cupidon')) { role = '§eCupidon'; roleEmoji = '💕'; }
        else if (player.hasTag('salvateur')) { role = '§fSalvateur'; roleEmoji = '🛡'; }
        else if (player.hasTag('petite_fille')) { role = '§ePetite§eFille'; roleEmoji = '👀'; }
        else if (player.hasTag('villageois')) { role = '§aVillageois'; roleEmoji = '🏠'; }
        

        let phase = '§7En attente...';
        if (timerConfig.currentPhase === 'day') {
            phase = '§e☀ JOUR';
        } else if (timerConfig.currentPhase === 'night') {
            phase = '§8🌙 NUIT';
        }
        

        player.server.runCommandSilent('scoreboard objectives add lameute dummy {"text":"§6§l🐺 LA MEUTE 🐺"}');
        player.server.runCommandSilent('scoreboard objectives setdisplay sidebar lameute');
        

        player.server.runCommandSilent('scoreboard players reset * lameute');
        

        player.server.runCommandSilent('scoreboard players set §8══════════ lameute 10');
        player.server.runCommandSilent('scoreboard players set §fVotre§frôle§f: lameute 9');
        player.server.runCommandSilent('scoreboard players set ' + roleEmoji + role + ' lameute 8');
        player.server.runCommandSilent('scoreboard players set §r lameute 7');
        player.server.runCommandSilent('scoreboard players set §fPhase§f: lameute 6');
        player.server.runCommandSilent('scoreboard players set ' + phase + ' lameute 5');
        player.server.runCommandSilent('scoreboard players set §r§r lameute 4');
        player.server.runCommandSilent('scoreboard players set §8═══════════ lameute 3');
        player.server.runCommandSilent('scoreboard players set §r§r§r lameute 2');
        player.server.runCommandSilent('scoreboard players set §7Dev:§6§lw9n0 lameute 1');
    }
    

    if (player.crouching && player.pitch < -60) {

        let role = 'Villageois';
        let color = '§a';
        
        if (player.hasTag('loup_garou')) { role = 'LOUP-GAROU 🐺'; color = '§c§l'; }
        else if (player.hasTag('voyante')) { role = 'Voyante 👁'; color = '§b'; }
        else if (player.hasTag('sorciere')) { role = 'Sorcière ⚗'; color = '§d'; }
        else if (player.hasTag('chasseur')) { role = 'Chasseur 🏹'; color = '§6'; }
        else if (player.hasTag('cupidon')) { role = 'Cupidon 💕'; color = '§e'; }
        else if (player.hasTag('salvateur')) { role = 'Salvateur 🛡'; color = '§f'; }
        else if (player.hasTag('petite_fille')) { role = 'Petite Fille 👀'; color = '§e'; }
        else if (player.hasTag('villageois')) { role = 'Villageois 🏠'; color = '§a'; }
        

        player.displayClientMessage(color + 'Votre rôle : ' + role, true);
    }
});


PlayerEvents.entityInteracted(event => {
    const player = event.player;
    const target = event.target;
    

    if (target.type === 'minecraft:player' && votePhaseActive) {
        const voterName = player.name.string;
        const targetName = target.name.string;
        

        votes[voterName] = targetName;
        

        player.tell('§6[Vote] §aVous avez voté contre §c' + targetName);
        

        player.level.players.forEach(p => {
            if (p.name.string !== voterName) {
                p.tell('§6[Vote] §e' + voterName + ' §7a voté !');
            }
        });
        

        player.level.playSound(null, player.blockPosition(), 
            'minecraft:block.note_block.pling', 'players', 1.0, 1.5);
    }
});


PlayerEvents.attack(event => {
    const player = event.player;
    const target = event.target;
    

    if (target.type === 'minecraft:player' && votePhaseActive) {
        const voterName = player.name.string;
        

        if (votes[voterName]) {
            delete votes[voterName];
            

            player.tell('§6[Vote] §eVous avez retiré votre vote.');
            

            player.level.players.forEach(p => {
                if (p.name.string !== voterName) {
                    p.tell('§6[Vote] §e' + voterName + ' §7a retiré son vote.');
                }
            });
            

            player.level.playSound(null, player.blockPosition(), 
                'minecraft:block.note_block.bass', 'players', 1.0, 0.8);
            

            event.cancel();
        } else {
            player.tell('§6[Vote] §7Vous n\'avez pas encore voté.');
            event.cancel();
        }
    }
});


PlayerEvents.tick(event => {
    const player = event.player;
    const level = player.level;
    

    const timeOfDay = level.getDayTime() % 24000;
    const isNight = timeOfDay >= 13000 && timeOfDay <= 23000;
    

    const moonPhase = level.getMoonPhase();
    const isFullMoon = moonPhase === 0;
    

    if (isNight && isFullMoon) {

        if (player.hasTag('loup_garou')) {
            player.potionEffects.add('minecraft:strength', 200, 1, false, false);
            player.potionEffects.add('minecraft:speed', 200, 1, false, false);
            player.potionEffects.add('minecraft:night_vision', 400, 0, false, false);
        }
        

        if (player.hasTag('villageois')) {

            if (Math.random() < 0.01) {
                player.tell('§c§oVous sentez une présence menaçante dans la nuit...');
            }
        }
    }
});


ServerEvents.commandRegistry(event => {
    const { commands: Commands, arguments: Arguments } = event;
    

    const requiresOP = (source) => source.hasPermission(2);
    

    event.register(
        Commands.literal('lameute')
            .requires(requiresOP)
            .then(Commands.literal('start')
                .then(Commands.argument('loups', Arguments.INTEGER.create(event))
                    .executes(ctx => {
                        const nbLoups = Arguments.INTEGER.getResult(ctx, 'loups');
                        const players = [];
                        
                        ctx.source.level.players.forEach(p => {
                            players.push(p);
                        });
                        
                        if (players.length < 4) {
                            ctx.source.player.tell('§c[La Meute] §7Il faut au moins 4 joueurs pour commencer !');
                            return 0;
                        }
                        
                        if (nbLoups >= players.length / 2) {
                            ctx.source.player.tell('§c[La Meute] §7Trop de loups-garous ! Maximum : ' + Math.floor(players.length / 2 - 1));
                            return 0;
                        }
                        

                        let roles = [];
                        

                        for (let i = 0; i < nbLoups; i++) {
                            roles.push('loup_garou');
                        }
                        

                        if (players.length >= 6) roles.push('voyante');
                        if (players.length >= 7) roles.push('sorciere');
                        if (players.length >= 8) roles.push('chasseur');
                        if (players.length >= 10) roles.push('cupidon');
                        if (players.length >= 12) roles.push('salvateur');
                        if (players.length >= 14) roles.push('petite_fille');
                        

                        while (roles.length < players.length) {
                            roles.push('villageois');
                        }
                        

                        roles = shuffleArray(roles);
                        

                        ctx.source.level.players.forEach(p => {
                            p.tell('');
                            p.tell('§8§l═══════════════════════════════════════════════════════');
                            p.tell('');
                            p.tell('§6§l           🐺 LA MEUTE - NOUVELLE PARTIE 🐺');
                            p.tell('');
                            p.tell('§7         Le village de §eThiercelieux §7s\'endort...');
                            p.tell('§7         Mais des loups-garous rôdent parmi vous.');
                            p.tell('');
                            p.tell('§8§l═══════════════════════════════════════════════════════');
                            p.tell('');
                            

                            p.level.playSound(null, p.blockPosition(), 
                                'minecraft:entity.ender_dragon.growl', 'ambient', 0.3, 0.5);
                        });
                        

                        gameStarted = true;
                        

                        for (let i = 0; i < players.length; i++) {
                            const player = players[i];
                            const role = roles[i];
                            

                            pendingCardReveal[player.name.string] = role;
                        }
                        

                        ctx.source.server.scheduleInTicks(40, () => {
                            ctx.source.level.players.forEach(p => {
                                p.tell('');
                                p.tell('§e§l   🎴 UNE CARTE MYSTÉRIEUSE APPARAÎT DEVANT VOUS... 🎴');
                                p.tell('');
                                p.tell('§a§l        ➤ FAITES UN CLIC DROIT POUR LA RETOURNER ! ➤');
                                p.tell('');
                                

                                p.server.runCommandSilent('title ' + p.name.string + ' times 10 60 20');
                                p.server.runCommandSilent('title ' + p.name.string + ' subtitle {"text":"Clic droit pour révéler votre rôle...","color":"gray","italic":true}');
                                p.server.runCommandSilent('title ' + p.name.string + ' title {"text":"🎴 VOTRE CARTE 🎴","color":"gold","bold":true}');
                                

                                p.level.playSound(null, p.blockPosition(), 
                                    'minecraft:block.enchantment_table.use', 'players', 1.0, 0.8);
                            });
                        });
                        

                        ctx.source.server.scheduleInTicks(200, () => {
                            for (let playerName in pendingCardReveal) {
                                ctx.source.level.players.forEach(p => {
                                    if (p.name.string === playerName && pendingCardReveal[playerName]) {
                                        const role = pendingCardReveal[playerName];
                                        delete pendingCardReveal[playerName];
                                        revealRoleToPlayer(p, role);
                                    }
                                });
                            }
                        });
                        
                        ctx.source.player.tell('§a[La Meute] §7Partie lancée avec §e' + players.length + ' joueurs §7et §c' + nbLoups + ' loup(s)-garou(s) §7!');
                        ctx.source.player.tell('§7Utilisez §e/lameute timer auto §7pour lancer le timer automatique !');
                        
                        return 1;
                    })
                )
            )
            .then(Commands.literal('timer')
                .then(Commands.literal('auto')
                    .executes(ctx => {
                        timerConfig.autoMode = true;
                        timerConfig.timerRunning = true;
                        timerConfig.currentPhase = 'day';
                        timerConfig.timerStartTime = Date.now();
                        votePhaseActive = true;
                        nightPhaseActive = false;
                        votes = {};
                        
                        ctx.source.level.setDayTime(1000);
                        
                        ctx.source.level.players.forEach(p => {
                            p.tell('');
                            p.tell('§a§l⏰ MODE AUTOMATIQUE ACTIVÉ !');
                            p.tell('§7La barre d\'XP indique le temps restant.');
                            p.tell('§7Jour : §e' + timerConfig.dayDuration + ' min §7| Nuit : §e' + timerConfig.nightDuration + ' min');
                            p.tell('');
                        });
                        
                        return 1;
                    })
                )
                .then(Commands.literal('stop')
                    .executes(ctx => {
                        timerConfig.autoMode = false;
                        timerConfig.timerRunning = false;
                        
                        ctx.source.level.players.forEach(p => {
                            p.tell('§c[Timer] §7Mode automatique désactivé.');
                            p.setExperienceLevel(0);
                            p.setExperienceProgress(0);
                        });
                        
                        return 1;
                    })
                )
                .then(Commands.literal('jour')
                    .then(Commands.argument('minutes', Arguments.INTEGER.create(event))
                        .executes(ctx => {
                            const minutes = Arguments.INTEGER.getResult(ctx, 'minutes');
                            
                            if (minutes !== 3 && minutes !== 5 && minutes !== 7) {
                                ctx.source.player.tell('§c[Timer] §7Valeurs autorisées : 3, 5 ou 7 minutes');
                                return 0;
                            }
                            
                            timerConfig.dayDuration = minutes;
                            ctx.source.player.tell('§a[Timer] §7Durée du jour : §e' + minutes + ' minutes');
                            return 1;
                        })
                    )
                )
                .then(Commands.literal('nuit')
                    .then(Commands.argument('minutes', Arguments.INTEGER.create(event))
                        .executes(ctx => {
                            const minutes = Arguments.INTEGER.getResult(ctx, 'minutes');
                            
                            timerConfig.nightDuration = minutes;
                            ctx.source.player.tell('§a[Timer] §7Durée de la nuit : §e' + minutes + ' minutes (max)');
                            return 1;
                        })
                    )
                )
            )
            .then(Commands.literal('roles')
                .executes(ctx => {

                    ctx.source.player.tell('§6§l=== RÔLES DISPONIBLES ===');
                    ctx.source.player.tell('§c• loup_garou §7- Dévore les villageois');
                    ctx.source.player.tell('§a• villageois §7- Simple villageois');
                    ctx.source.player.tell('§b• voyante §7- Voit les rôles');
                    ctx.source.player.tell('§d• sorciere §7- Potions vie/mort');
                    ctx.source.player.tell('§6• chasseur §7- Tire en mourant');
                    ctx.source.player.tell('§e• cupidon §7- Lie les amoureux');
                    ctx.source.player.tell('§f• salvateur §7- Protège la nuit');
                    ctx.source.player.tell('§e• petite_fille §7- Espionne');
                    return 1;
                })
            )
    );
    

    event.register(
        Commands.literal('lameute')
            .requires(requiresOP)
            .then(Commands.literal('arene')
                .then(Commands.literal('set')
                    .executes(ctx => {
                        const player = ctx.source.player;
                        arenaCenter.x = Math.floor(player.x);
                        arenaCenter.y = Math.floor(player.y);
                        arenaCenter.z = Math.floor(player.z);
                        arenaCenter.set = true;
                        
                        player.tell('§a[Arène] §7Centre défini à §e' + arenaCenter.x + ' ' + arenaCenter.y + ' ' + arenaCenter.z);
                        player.tell('§7Utilisez §e/lameute arene rayon <nombre> §7pour modifier le rayon (défaut: 5)');
                        return 1;
                    })
                )
                .then(Commands.literal('rayon')
                    .then(Commands.argument('size', Arguments.INTEGER.create(event))
                        .executes(ctx => {
                            const size = Arguments.INTEGER.getResult(ctx, 'size');
                            arenaCenter.radius = Math.max(2, Math.min(size, 20));
                            ctx.source.player.tell('§a[Arène] §7Rayon du cercle : §e' + arenaCenter.radius + ' blocs');
                            return 1;
                        })
                    )
                )
                .then(Commands.literal('tp')
                    .executes(ctx => {
                        if (!arenaCenter.set) {
                            ctx.source.player.tell('§c[Arène] §7Aucune arène définie ! Utilisez §e/lameute arene set');
                            return 0;
                        }
                        
                        const count = teleportPlayersInCircle(ctx.source.server);
                        
                        ctx.source.level.players.forEach(p => {
                            p.tell('§a[Arène] §7Téléportation en cercle ! §e' + count + ' joueurs');
                            p.level.playSound(null, p.blockPosition(), 
                                'minecraft:entity.enderman.teleport', 'players', 1.0, 1.0);
                        });
                        
                        return 1;
                    })
                )
                .then(Commands.literal('info')
                    .executes(ctx => {
                        if (!arenaCenter.set) {
                            ctx.source.player.tell('§c[Arène] §7Aucune arène définie !');
                            return 0;
                        }
                        ctx.source.player.tell('§6§l=== ARÈNE ===');
                        ctx.source.player.tell('§7Centre : §e' + arenaCenter.x + ' ' + arenaCenter.y + ' ' + arenaCenter.z);
                        ctx.source.player.tell('§7Rayon : §e' + arenaCenter.radius + ' blocs');
                        return 1;
                    })
                )
            )
    );
    

    event.register(
        Commands.literal('lameute')
            .requires(requiresOP)
            .then(Commands.literal('role')
                .then(Commands.argument('player', Arguments.PLAYER.create(event))
                    .then(Commands.argument('role', Arguments.STRING.create(event))
                        .executes(ctx => {
                            const targetPlayer = Arguments.PLAYER.getResult(ctx, 'player');
                            const role = Arguments.STRING.getResult(ctx, 'role');
                            

                            const roles = ['loup_garou', 'villageois', 'voyante', 'sorciere', 
                                         'chasseur', 'cupidon', 'salvateur', 'petite_fille', 
                                         'ancien', 'idiot'];
                            roles.forEach(r => targetPlayer.removeTag(r));
                            

                            targetPlayer.addTag(role);
                            targetPlayer.tell('§6§l[La Meute] §rVotre rôle est maintenant : §e' + role);
                            
                            return 1;
                        })
                    )
                )
            )
            .then(Commands.literal('nuit')
                .executes(ctx => {
                    ctx.source.level.setDayTime(13000);
                    votePhaseActive = false; // Désactiver le vote la nuit
                    nightPhaseActive = true; // Activer la phase de nuit pour les pouvoirs
                    

                    voyantePowerUsed = {};
                    loupVotes = {};
                    

                    ctx.source.level.players.forEach(p => {
                        p.removeTag('protected_tonight');
                    });
                    
                    ctx.source.level.players.forEach(p => {
                        p.tell('§8§l═══════════════════════════════════════════════════');
                        p.tell('§c§l              🌙 LA NUIT TOMBE 🌙');
                        p.tell('§7     Le village s\'endort... Les loups se réveillent.');
                        p.tell('');
                        if (p.hasTag('loup_garou')) {
                            p.tell('§c     🐺 Utilisez un OS sur un joueur pour le dévorer');
                        }
                        if (p.hasTag('voyante')) {
                            p.tell('§b     👁 Utilisez un ŒIL D\'ARAIGNÉE pour voir un rôle');
                        }
                        if (p.hasTag('sorciere')) {
                            p.tell('§d     ⚗ POMME DORÉE = vie | ROSE DES TÉNÈBRES = mort');
                        }
                        if (p.hasTag('salvateur')) {
                            p.tell('§f     🛡 Utilisez un BOUCLIER pour protéger quelqu\'un');
                        }
                        p.tell('§8§l═══════════════════════════════════════════════════');
                    });
                    

                    ctx.source.level.playSound(null, ctx.source.player.blockPosition(),
                        'minecraft:entity.wolf.howl', 'ambient', 1.0, 0.6);
                    
                    return 1;
                })
            )
            .then(Commands.literal('jour')
                .executes(ctx => {
                    ctx.source.level.setDayTime(1000);
                    votePhaseActive = true; // Activer la phase de vote
                    nightPhaseActive = false; // Désactiver la phase de nuit
                    votes = {}; // Réinitialiser les votes
                    

                    let loupTarget = null;
                    let loupVoteCount = {};
                    
                    for (let loup in loupVotes) {
                        let target = loupVotes[loup];
                        loupVoteCount[target] = (loupVoteCount[target] || 0) + 1;
                    }
                    
                    let maxLoupVotes = 0;
                    for (let target in loupVoteCount) {
                        if (loupVoteCount[target] > maxLoupVotes) {
                            maxLoupVotes = loupVoteCount[target];
                            loupTarget = target;
                        }
                    }
                    

                    let victimProtected = false;
                    if (loupTarget) {
                        ctx.source.level.players.forEach(p => {
                            if (p.name.string === loupTarget && p.hasTag('protected_tonight')) {
                                victimProtected = true;
                            }
                        });
                    }
                    
                    ctx.source.level.players.forEach(p => {
                        p.tell('§6§l═══════════════════════════════════════════════════');
                        p.tell('§e§l              ☀️ LE JOUR SE LÈVE ☀️');
                        p.tell('');
                        
                        if (loupTarget && !victimProtected) {
                            p.tell('§c§l   ☠ ' + loupTarget + ' a été dévoré cette nuit... ☠');
                            

                            if (p.name.string === loupTarget) {
                                p.tell('§4§l   VOUS AVEZ ÉTÉ DÉVORÉ PAR LES LOUPS-GAROUS !');
                                p.kill();
                            }
                        } else if (loupTarget && victimProtected) {
                            p.tell('§a   ✨ Le Salvateur a protégé quelqu\'un cette nuit !');
                            p.tell('§7   Personne n\'est mort.');
                        } else {
                            p.tell('§7   Personne n\'est mort cette nuit.');
                        }
                        
                        p.tell('');
                        p.tell('§a§l   👆 CLIC DROIT sur un joueur pour VOTER !');
                        p.tell('§7      Clic gauche pour retirer votre vote.');
                        p.tell('§6§l═══════════════════════════════════════════════════');
                    });
                    

                    ctx.source.level.playSound(null, ctx.source.player.blockPosition(),
                        'minecraft:entity.chicken.ambient', 'ambient', 2.0, 0.8);
                    
                    return 1;
                })
            )
            .then(Commands.literal('resultat')
                .executes(ctx => {

                    let voteCount = {};
                    for (let voter in votes) {
                        let target = votes[voter];
                        voteCount[target] = (voteCount[target] || 0) + 1;
                    }
                    

                    let maxVotes = 0;
                    let eliminated = null;
                    for (let player in voteCount) {
                        if (voteCount[player] > maxVotes) {
                            maxVotes = voteCount[player];
                            eliminated = player;
                        }
                    }
                    
                    ctx.source.level.players.forEach(p => {
                        p.tell('§6§l═══════════════════════════════════════════════════');
                        p.tell('§c§l              ⚖️ RÉSULTAT DU VOTE ⚖️');
                        p.tell('');
                        

                        for (let voter in votes) {
                            p.tell('§7  ' + voter + ' → §c' + votes[voter]);
                        }
                        
                        p.tell('');
                        if (eliminated) {
                            p.tell('§4§l  ☠ ' + eliminated + ' est éliminé avec ' + maxVotes + ' vote(s) !');
                        } else {
                            p.tell('§7  Aucun vote enregistré.');
                        }
                        p.tell('§6§l═══════════════════════════════════════════════════');
                    });
                    

                    ctx.source.level.playSound(null, ctx.source.player.blockPosition(),
                        'minecraft:entity.lightning_bolt.thunder', 'players', 0.5, 0.8);
                    
                    votes = {}; // Réinitialiser pour le prochain tour
                    return 1;
                })
            )
            .then(Commands.literal('hurlement')
                .executes(ctx => {
                    const player = ctx.source.player;
                    player.level.playSound(null, player.blockPosition(), 
                        'minecraft:entity.wolf.howl', 'players', 3.0, 0.5);
                    
                    ctx.source.level.players.forEach(p => {
                        p.tell('§8§o*Un hurlement sinistre résonne dans la nuit...*');
                    });
                    return 1;
                })
            )
    );
    
    // ============================================

    // ============================================
    event.register(
        Commands.literal('tab')
            .requires(source => source.hasPermission(2)) // OP seulement
            .then(Commands.argument('joueur', Arguments.STRING.create(event))
                .then(Commands.argument('titre', Arguments.GREEDY_STRING.create(event))
                    .executes(ctx => {
                        const targetName = Arguments.STRING.getResult(ctx, 'joueur');
                        const titre = Arguments.GREEDY_STRING.getResult(ctx, 'titre');
                        

                        let targetPlayer = null;
                        ctx.source.level.players.forEach(p => {
                            if (p.name.string.toLowerCase() === targetName.toLowerCase()) {
                                targetPlayer = p;
                            }
                        });
                        
                        if (!targetPlayer) {
                            ctx.source.player.tell('§c[Tab] §7Joueur "' + targetName + '" non trouvé !');
                            return 0;
                        }
                        

                        playerTitles[targetPlayer.name.string] = titre;
                        

                        updatePlayerDisplayName(targetPlayer);
                        
                        const formattedTitle = getFormattedTitle(titre);
                        ctx.source.player.tell('§a[Tab] §7Titre de §f' + targetPlayer.name.string + ' §7changé en : ' + formattedTitle);
                        targetPlayer.tell('§a[Tab] §7Votre titre a été changé en : ' + formattedTitle);
                        

                        ctx.source.level.players.forEach(p => {
                            p.tell('§8[Tab] §f' + targetPlayer.name.string + ' §7est maintenant : ' + formattedTitle.trim());
                        });
                        
                        return 1;
                    })
                )
            )
            .then(Commands.literal('remove')
                .then(Commands.argument('joueur', Arguments.STRING.create(event))
                    .executes(ctx => {
                        const targetName = Arguments.STRING.getResult(ctx, 'joueur');
                        
                        let targetPlayer = null;
                        ctx.source.level.players.forEach(p => {
                            if (p.name.string.toLowerCase() === targetName.toLowerCase()) {
                                targetPlayer = p;
                            }
                        });
                        
                        if (!targetPlayer) {
                            ctx.source.player.tell('§c[Tab] §7Joueur "' + targetName + '" non trouvé !');
                            return 0;
                        }
                        

                        delete playerTitles[targetPlayer.name.string];
                        

                        updatePlayerDisplayName(targetPlayer);
                        
                        ctx.source.player.tell('§a[Tab] §7Titre de §f' + targetPlayer.name.string + ' §7retiré.');
                        return 1;
                    })
                )
            )
            .then(Commands.literal('list')
                .executes(ctx => {
                    ctx.source.player.tell('§6§l═══ TITRES DISPONIBLES ═══');
                    ctx.source.player.tell('§7• §b§l[DEV] §7- dev');
                    ctx.source.player.tell('§7• §6§l[MJ] §7- maitre du jeu / mj');
                    ctx.source.player.tell('§7• §4§l[OWNER] §7- owner');
                    ctx.source.player.tell('§7• §c§l[ADMIN] §7- admin');
                    ctx.source.player.tell('§7• §e§l[MODO] §7- modo');
                    ctx.source.player.tell('§7• §a§l[VIP] §7- vip');
                    ctx.source.player.tell('§7• §d§l[Tasty Crousty] §7- tasty crousty');
                    ctx.source.player.tell('§7• §6§l[Chicken Street] §7- chicken street');
                    ctx.source.player.tell('§7• §7[Joueur] §7- joueur (défaut)');
                    ctx.source.player.tell('§e§l═══════════════════════');
                    ctx.source.player.tell('§7Usage: §f/tab <joueur> <titre>');
                    return 1;
                })
            )
    );
});


ServerEvents.recipes(event => {

    event.shaped('minecraft:iron_sword', [
        ' I ',
        ' I ',
        ' S '
    ], {
        I: 'minecraft:iron_ingot',
        S: 'minecraft:stick'
    }).id('lameute:silver_sword');
    

    event.shapeless('minecraft:potion', [
        'minecraft:glass_bottle',
        'minecraft:glistering_melon_slice',
        'minecraft:golden_apple'
    ]).id('lameute:potion_vie');
    

    event.shapeless('minecraft:splash_potion', [
        'minecraft:glass_bottle',
        'minecraft:wither_rose',
        'minecraft:spider_eye'
    ]).id('lameute:potion_mort');
});


PlayerEvents.loggedIn(event => {
    const player = event.player;
    

    

    player.server.scheduleInTicks(20, () => {
        updatePlayerDisplayName(player);
    });
    
    player.tell('');
    player.tell('§8§l═══════════════════════════════════════════════');
    player.tell('§6§l           🐺 BIENVENUE DANS LA MEUTE 🐺');
    player.tell('§8§l═══════════════════════════════════════════════');
    player.tell('');
    player.tell('§7Bienvenue dans le village de §eThiercelieux§7.');
    player.tell('§7La nuit, les §cloups-garous §7chassent...');
    player.tell('§7Le jour, le village vote pour éliminer les suspects.');
    player.tell('');
    player.tell('§aCommandes :');
    player.tell('§7  /lameute start [loups] §8- Lancer une partie');
    player.tell('§7  /lameute timer auto §8- Timer automatique');
    player.tell('§7  /lameute timer jour [3/5/7] §8- Durée du jour');
    player.tell('');
    player.tell('§e💡 Votre rôle s\'affiche dans le scoreboard à droite !');
    player.tell('');
    player.tell('§c§l              QUE LA CHASSE COMMENCE !');
    player.tell('');
    player.tell('§8              Développé par §6§lw9n0 §8🐺');
    player.tell('§8§l═══════════════════════════════════════════════');
    player.tell('');
});

// ============================================

// ============================================
PlayerEvents.chat(event => {
    const player = event.player;
    const playerName = player.name.string;
    const message = event.message;
    

    const title = playerTitles[playerName] || 'Joueur';
    const formattedTitle = getFormattedTitle(title);
    

    event.cancel();
    

    const formattedMessage = formattedTitle + '§f' + playerName + ' §7» §f' + message;
    
    player.server.players.forEach(p => {
        p.tell(formattedMessage);
    });
    

    console.log('[Chat] ' + title + ' ' + playerName + ': ' + message);
});
